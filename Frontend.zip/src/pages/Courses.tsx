import Editor from "@/components/editor";

function Courses() {
  return (
    <div className="flex flex-col items-center h-full w-full">
      <div
        className="pt-5 pb-[70svh] w-full max-w-[1000px] font-inherit"
        spellCheck="false"
      >
        <Editor />
      </div>
    </div>
  );
}

export default Courses;
