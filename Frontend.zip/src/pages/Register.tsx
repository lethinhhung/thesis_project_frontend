import { RegisterForm } from "@/components/register-form";

function Register() {
  return <RegisterForm />;
}

export default Register;
