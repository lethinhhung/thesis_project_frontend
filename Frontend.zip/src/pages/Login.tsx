import { LoginForm } from "@/components/login-form";

function Login() {
  return <LoginForm />;
}

export default Login;
