function Library() {
  return (
    <div className="flex flex-col items-center mx-auto h-full w-full max-w-3xl rounded-xl bg-muted/50">
      Library page
    </div>
  );
}

export default Library;
